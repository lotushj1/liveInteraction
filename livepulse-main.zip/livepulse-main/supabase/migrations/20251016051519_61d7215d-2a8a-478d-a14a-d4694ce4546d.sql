-- 新增 SELECT 政策，允許所有人查詢參與者（用於加入驗證）
CREATE POLICY "Anyone can view participants for join validation"
ON public.event_participants
FOR SELECT
TO authenticated, anon
USING (true);