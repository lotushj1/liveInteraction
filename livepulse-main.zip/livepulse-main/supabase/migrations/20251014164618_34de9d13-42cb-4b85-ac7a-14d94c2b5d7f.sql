-- Add event_type enum and column to events table
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'event_type') THEN
    CREATE TYPE event_type AS ENUM ('qna', 'quiz');
  END IF;
END $$;

ALTER TABLE public.events 
ADD COLUMN IF NOT EXISTS event_type event_type NOT NULL DEFAULT 'qna';

COMMENT ON COLUMN public.events.event_type IS '活動類型：qna(Q&A互動問答) 或 quiz(競賽問答)';