-- 修復 event_participants 的 INSERT 政策，允許匿名用戶加入活動

-- 1. 刪除現有的插入政策
DROP POLICY IF EXISTS "Users can join events" ON public.event_participants;

-- 2. 建立新的插入政策
CREATE POLICY "Users and anonymous can join events" 
ON public.event_participants
FOR INSERT
WITH CHECK (
  -- 情況 1: 已登入用戶只能插入自己的 user_id
  (auth.uid() IS NOT NULL AND user_id = auth.uid())
  OR
  -- 情況 2: 未登入用戶只能插入 user_id 為 null 的匿名記錄
  (auth.uid() IS NULL AND user_id IS NULL)
);