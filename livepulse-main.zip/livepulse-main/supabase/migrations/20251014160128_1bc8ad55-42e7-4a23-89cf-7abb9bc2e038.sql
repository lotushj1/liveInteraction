-- Phase 1: 參與者介面資料庫擴充

-- 1. 問題狀態枚舉
CREATE TYPE public.question_status AS ENUM ('pending', 'approved', 'rejected', 'answered');

-- 2. 投票類型枚舉
CREATE TYPE public.poll_type AS ENUM ('single_choice', 'multiple_choice', 'word_cloud', 'rating');

-- 3. 活動模式枚舉
CREATE TYPE public.event_mode AS ENUM ('lobby', 'quiz', 'qna', 'poll');

-- 4. Q&A 問題表
CREATE TABLE public.questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_id UUID NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
    participant_id UUID REFERENCES public.event_participants(id) ON DELETE CASCADE,
    content TEXT NOT NULL CHECK (char_length(content) BETWEEN 1 AND 500),
    status question_status NOT NULL DEFAULT 'pending',
    upvote_count INTEGER NOT NULL DEFAULT 0,
    is_highlighted BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    answered_at TIMESTAMPTZ
);

-- 5. 問題按讚記錄表
CREATE TABLE public.question_upvotes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
    participant_id UUID NOT NULL REFERENCES public.event_participants(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(question_id, participant_id)
);

-- 6. 投票表
CREATE TABLE public.polls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_id UUID NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    poll_type poll_type NOT NULL,
    options JSONB,
    is_active BOOLEAN NOT NULL DEFAULT false,
    is_closed BOOLEAN NOT NULL DEFAULT false,
    max_selections INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at TIMESTAMPTZ
);

-- 7. 投票回應表
CREATE TABLE public.poll_responses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    poll_id UUID NOT NULL REFERENCES public.polls(id) ON DELETE CASCADE,
    participant_id UUID NOT NULL REFERENCES public.event_participants(id) ON DELETE CASCADE,
    response JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(poll_id, participant_id)
);

-- 8. 問答競賽表
CREATE TABLE public.quizzes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_id UUID NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT false,
    current_question_index INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 9. 問答題目表
CREATE TABLE public.quiz_questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    quiz_id UUID NOT NULL REFERENCES public.quizzes(id) ON DELETE CASCADE,
    question_order INTEGER NOT NULL,
    question_text TEXT NOT NULL,
    options JSONB NOT NULL,
    time_limit INTEGER NOT NULL DEFAULT 30,
    points INTEGER NOT NULL DEFAULT 100,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 10. 答題記錄表
CREATE TABLE public.quiz_responses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    quiz_question_id UUID NOT NULL REFERENCES public.quiz_questions(id) ON DELETE CASCADE,
    participant_id UUID NOT NULL REFERENCES public.event_participants(id) ON DELETE CASCADE,
    selected_option INTEGER NOT NULL,
    is_correct BOOLEAN NOT NULL,
    response_time INTEGER NOT NULL,
    points_earned INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(quiz_question_id, participant_id)
);

-- 11. 擴充 events 表
ALTER TABLE public.events
ADD COLUMN current_mode event_mode NOT NULL DEFAULT 'lobby',
ADD COLUMN current_quiz_id UUID REFERENCES public.quizzes(id) ON DELETE SET NULL,
ADD COLUMN current_poll_id UUID REFERENCES public.polls(id) ON DELETE SET NULL;

-- 12. 建立索引提升查詢效能
CREATE INDEX idx_questions_event_id ON public.questions(event_id);
CREATE INDEX idx_questions_status ON public.questions(status);
CREATE INDEX idx_question_upvotes_question_id ON public.question_upvotes(question_id);
CREATE INDEX idx_polls_event_id ON public.polls(event_id);
CREATE INDEX idx_poll_responses_poll_id ON public.poll_responses(poll_id);
CREATE INDEX idx_quizzes_event_id ON public.quizzes(event_id);
CREATE INDEX idx_quiz_questions_quiz_id ON public.quiz_questions(quiz_id);
CREATE INDEX idx_quiz_responses_participant_id ON public.quiz_responses(participant_id);

-- 13. RLS 政策 - questions 表
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants can view approved questions"
ON public.questions FOR SELECT
USING (
    status IN ('approved', 'answered') AND
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.event_id = questions.event_id
        AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
    )
);

CREATE POLICY "Participants can submit questions"
ON public.questions FOR INSERT
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.id = questions.participant_id
        AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
    )
);

CREATE POLICY "Hosts can manage questions"
ON public.questions FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM public.events
        WHERE events.id = questions.event_id
        AND events.host_id = auth.uid()
    )
);

-- 14. RLS 政策 - question_upvotes 表
ALTER TABLE public.question_upvotes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants can view upvotes"
ON public.question_upvotes FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.id = question_upvotes.participant_id
    )
);

CREATE POLICY "Participants can upvote"
ON public.question_upvotes FOR INSERT
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.id = question_upvotes.participant_id
        AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
    )
);

CREATE POLICY "Participants can remove upvote"
ON public.question_upvotes FOR DELETE
USING (
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.id = question_upvotes.participant_id
        AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
    )
);

-- 15. RLS 政策 - polls 表
ALTER TABLE public.polls ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants can view active polls"
ON public.polls FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.event_id = polls.event_id
    )
);

CREATE POLICY "Hosts can manage polls"
ON public.polls FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM public.events
        WHERE events.id = polls.event_id
        AND events.host_id = auth.uid()
    )
);

-- 16. RLS 政策 - poll_responses 表
ALTER TABLE public.poll_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants can view own responses"
ON public.poll_responses FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.id = poll_responses.participant_id
        AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
    )
);

CREATE POLICY "Participants can submit responses"
ON public.poll_responses FOR INSERT
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.id = poll_responses.participant_id
        AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
    )
);

CREATE POLICY "Hosts can view all responses"
ON public.poll_responses FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM public.polls
        JOIN public.events ON events.id = polls.event_id
        WHERE polls.id = poll_responses.poll_id
        AND events.host_id = auth.uid()
    )
);

-- 17. RLS 政策 - quizzes 表
ALTER TABLE public.quizzes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants can view active quizzes"
ON public.quizzes FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.event_id = quizzes.event_id
    )
);

CREATE POLICY "Hosts can manage quizzes"
ON public.quizzes FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM public.events
        WHERE events.id = quizzes.event_id
        AND events.host_id = auth.uid()
    )
);

-- 18. RLS 政策 - quiz_questions 表
ALTER TABLE public.quiz_questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants can view questions"
ON public.quiz_questions FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM public.quizzes
        JOIN public.event_participants ON event_participants.event_id = quizzes.event_id
        WHERE quizzes.id = quiz_questions.quiz_id
    )
);

CREATE POLICY "Hosts can manage questions"
ON public.quiz_questions FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM public.quizzes
        JOIN public.events ON events.id = quizzes.event_id
        WHERE quizzes.id = quiz_questions.quiz_id
        AND events.host_id = auth.uid()
    )
);

-- 19. RLS 政策 - quiz_responses 表
ALTER TABLE public.quiz_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants can view own responses"
ON public.quiz_responses FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.id = quiz_responses.participant_id
        AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
    )
);

CREATE POLICY "Participants can submit answers"
ON public.quiz_responses FOR INSERT
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.event_participants
        WHERE event_participants.id = quiz_responses.participant_id
        AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
    )
);

CREATE POLICY "Hosts can view all responses"
ON public.quiz_responses FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM public.quiz_questions
        JOIN public.quizzes ON quizzes.id = quiz_questions.quiz_id
        JOIN public.events ON events.id = quizzes.event_id
        WHERE quiz_questions.id = quiz_responses.quiz_question_id
        AND events.host_id = auth.uid()
    )
);

-- 20. 更新問題按讚數的觸發器函數
CREATE OR REPLACE FUNCTION public.update_question_upvote_count()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE public.questions
        SET upvote_count = upvote_count + 1
        WHERE id = NEW.question_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE public.questions
        SET upvote_count = GREATEST(upvote_count - 1, 0)
        WHERE id = OLD.question_id;
    END IF;
    RETURN NULL;
END;
$$;

CREATE TRIGGER update_question_upvote_count_trigger
AFTER INSERT OR DELETE ON public.question_upvotes
FOR EACH ROW EXECUTE FUNCTION public.update_question_upvote_count();