-- 建立安全輔助函數：檢查用戶是否為活動參與者
CREATE OR REPLACE FUNCTION public.is_event_participant(_user_id uuid, _event_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.event_participants
    WHERE event_id = _event_id 
      AND (user_id = _user_id OR user_id IS NULL)
  )
$$;

-- 建立安全輔助函數：檢查用戶是否為活動主持人
CREATE OR REPLACE FUNCTION public.is_event_host(_user_id uuid, _event_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.events
    WHERE id = _event_id 
      AND host_id = _user_id
  )
$$;

-- === 修改 event_participants 表的 RLS 政策 ===

-- 刪除有問題的政策
DROP POLICY IF EXISTS "Participants can view other participants" ON public.event_participants;

-- 建立新的政策，使用安全函數
CREATE POLICY "Participants can view same event participants"
ON public.event_participants
FOR SELECT
USING (
  public.is_event_participant(auth.uid(), event_id)
  OR public.is_event_host(auth.uid(), event_id)
);

-- === 更新 quizzes 表的 RLS 政策 ===

DROP POLICY IF EXISTS "Participants can view active quizzes" ON public.quizzes;

CREATE POLICY "Participants can view active quizzes"
ON public.quizzes
FOR SELECT
USING (public.is_event_participant(auth.uid(), event_id));

-- === 更新 quiz_questions 表的 RLS 政策 ===

DROP POLICY IF EXISTS "Participants can view questions" ON public.quiz_questions;

CREATE POLICY "Participants can view questions"
ON public.quiz_questions
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.quizzes
    WHERE quizzes.id = quiz_questions.quiz_id
      AND public.is_event_participant(auth.uid(), quizzes.event_id)
  )
);

-- === 更新 polls 表的 RLS 政策 ===

DROP POLICY IF EXISTS "Participants can view active polls" ON public.polls;

CREATE POLICY "Participants can view active polls"
ON public.polls
FOR SELECT
USING (public.is_event_participant(auth.uid(), event_id));

-- === 更新 poll_responses 表的 RLS 政策 ===

DROP POLICY IF EXISTS "Participants can submit responses" ON public.poll_responses;
DROP POLICY IF EXISTS "Participants can view own responses" ON public.poll_responses;

CREATE POLICY "Participants can submit responses"
ON public.poll_responses
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.event_participants
    WHERE event_participants.id = poll_responses.participant_id
      AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
  )
);

CREATE POLICY "Participants can view own responses"
ON public.poll_responses
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.event_participants
    WHERE event_participants.id = poll_responses.participant_id
      AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
  )
);

-- === 更新 questions 表的 RLS 政策 ===

DROP POLICY IF EXISTS "Participants can view approved questions" ON public.questions;
DROP POLICY IF EXISTS "Participants can submit questions" ON public.questions;

CREATE POLICY "Participants can view approved questions"
ON public.questions
FOR SELECT
USING (
  status IN ('approved', 'answered')
  AND public.is_event_participant(auth.uid(), event_id)
);

CREATE POLICY "Participants can submit questions"
ON public.questions
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.event_participants
    WHERE event_participants.id = questions.participant_id
      AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
  )
);

-- === 更新 question_upvotes 表的 RLS 政策 ===

DROP POLICY IF EXISTS "Participants can view upvotes" ON public.question_upvotes;
DROP POLICY IF EXISTS "Participants can upvote" ON public.question_upvotes;
DROP POLICY IF EXISTS "Participants can remove upvote" ON public.question_upvotes;

CREATE POLICY "Participants can view upvotes"
ON public.question_upvotes
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.event_participants
    WHERE event_participants.id = question_upvotes.participant_id
  )
);

CREATE POLICY "Participants can upvote"
ON public.question_upvotes
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.event_participants
    WHERE event_participants.id = question_upvotes.participant_id
      AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
  )
);

CREATE POLICY "Participants can remove upvote"
ON public.question_upvotes
FOR DELETE
USING (
  EXISTS (
    SELECT 1
    FROM public.event_participants
    WHERE event_participants.id = question_upvotes.participant_id
      AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
  )
);

-- === 更新 quiz_responses 表的 RLS 政策 ===

DROP POLICY IF EXISTS "Participants can submit answers" ON public.quiz_responses;
DROP POLICY IF EXISTS "Participants can view own responses" ON public.quiz_responses;

CREATE POLICY "Participants can submit answers"
ON public.quiz_responses
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.event_participants
    WHERE event_participants.id = quiz_responses.participant_id
      AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
  )
);

CREATE POLICY "Participants can view own responses"
ON public.quiz_responses
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.event_participants
    WHERE event_participants.id = quiz_responses.participant_id
      AND (event_participants.user_id = auth.uid() OR event_participants.user_id IS NULL)
  )
);