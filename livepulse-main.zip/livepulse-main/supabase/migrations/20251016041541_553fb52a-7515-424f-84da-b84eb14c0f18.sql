-- 修復 events 的 SELECT 政策，允許匿名用戶查詢活動

-- 1. 刪除現有的 SELECT 政策
DROP POLICY IF EXISTS "Anyone can view events by join code" ON public.events;

-- 2. 建立新的 SELECT 政策，同時支援已登入和匿名用戶
CREATE POLICY "Anyone can view events by join code" 
ON public.events
FOR SELECT
TO authenticated, anon  -- 允許已登入用戶和匿名用戶
USING (true);  -- 允許所有人查詢（應用層已用 join_code 過濾）