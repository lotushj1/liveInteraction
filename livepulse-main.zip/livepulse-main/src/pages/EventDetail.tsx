import { useParams, useNavigate } from 'react-router-dom';
import { useEvent, useEvents } from '@/hooks/useEvents';
import { useEventParticipants } from '@/hooks/useEventParticipants';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { JoinCodeDisplay } from '@/components/JoinCodeDisplay';
import { QuizManager } from '@/components/quiz/QuizManager';
import { ArrowLeft, Calendar, Users, Loader2, Play, Square, Monitor } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhTW } from 'date-fns/locale';
import QRCode from 'react-qr-code';

export default function EventDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { event, isLoading } = useEvent(id!);
  const { updateEvent, isUpdating } = useEvents();
  const { participants, participantCount } = useEventParticipants(id!);

  // 切換公開狀態
  const handleTogglePublic = async () => {
    if (!event) return;
    
    const updates = {
      is_active: !event.is_active,
      ...(!event.is_active 
        ? { started_at: new Date().toISOString() }
        : { 
            ended_at: new Date().toISOString(),
            current_mode: 'lobby' as const
          }
      ),
    };
    
    updateEvent({ id: event.id, updates });
  };

  // 切換活動模式
  const handleToggleMode = async () => {
    if (!event) return;
    
    const newMode = event.current_mode === 'lobby' 
      ? (event.event_type === 'quiz' ? 'quiz' : 'qna')
      : 'lobby';
    
    updateEvent({ 
      id: event.id, 
      updates: { current_mode: newMode as any }
    });
  };

  const joinUrl = event ? `https://livepulse.ovable.app/join?code=${event.join_code}` : '';

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">找不到活動</h2>
          <Button onClick={() => navigate('/dashboard')}>返回儀表板</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Button
          variant="ghost"
          onClick={() => navigate('/dashboard')}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          返回儀表板
        </Button>

        <div className="space-y-6 animate-fade-in">
          {/* 活動標題與狀態 */}
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-4xl font-bold">{event.title}</h1>
                <Badge 
                  variant={event.event_type === 'quiz' ? 'default' : 'outline'}
                  className={`text-lg px-4 py-2 ${
                    event.event_type === 'quiz' 
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 border-0' 
                      : 'border-blue-500 text-blue-500'
                  }`}
                >
                  {event.event_type === 'quiz' ? '🎯 Quiz 競賽問答' : '💬 Q&A 互動問答'}
                </Badge>
              </div>
              {event.description && (
                <p className="text-muted-foreground">{event.description}</p>
              )}
            </div>
            <div className="flex flex-col items-end gap-2">
              <Badge variant={event.is_active ? "default" : "secondary"} className="text-lg px-4 py-2">
                {event.is_active ? '🔓 已公開' : '🔒 未公開'}
              </Badge>
              <Badge variant="outline" className="text-sm px-3 py-1">
                {event.current_mode === 'lobby' ? '⏸️ 等候室' : '▶️ 進行中'}
              </Badge>
            </div>
          </div>

          {/* 活動資訊 */}
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>活動資訊</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <span>建立於 {formatDistanceToNow(new Date(event.created_at), { addSuffix: true, locale: zhTW })}</span>
              </div>
              {event.qna_enabled && (
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Q&A 已啟用</Badge>
                </div>
              )}
            </CardContent>
          </Card>

          {/* 加入碼展示 */}
          <JoinCodeDisplay code={event.join_code} />

          {/* Tabs: 活動資訊 / Quiz 管理 */}
          <Tabs defaultValue="info" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="info">活動資訊</TabsTrigger>
              {event.event_type === 'quiz' && (
                <TabsTrigger value="quiz">Quiz 管理</TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="info" className="space-y-6">
              {/* QR Code 區域 */}
              <Card className="glass-card shadow-card">
                <CardHeader>
                  <CardTitle>QR Code</CardTitle>
                  <CardDescription>參與者可以掃描此 QR Code 快速加入活動</CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center py-8">
                  <div className="inline-block p-6 bg-white rounded-lg shadow-sm">
                    <QRCode 
                      value={joinUrl}
                      size={192}
                      level="M"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* 參與者列表 */}
              <Card className="shadow-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Users className="w-5 h-5" />
                      參與者
                    </CardTitle>
                    <Badge variant="secondary">{participantCount} 人</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  {participantCount === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>還沒有參與者加入</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {participants.map((participant) => (
                        <div key={participant.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                          <span className="font-medium">{participant.nickname}</span>
                          <span className="text-sm text-muted-foreground">
                            {formatDistanceToNow(new Date(participant.joined_at), { addSuffix: true, locale: zhTW })}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {event.event_type === 'quiz' && (
              <TabsContent value="quiz">
                <QuizManager eventId={event.id} />
              </TabsContent>
            )}
          </Tabs>

          {/* 操作按鈕 */}
          <div className="flex gap-4">
            <Button
              variant="outline"
              size="lg"
              onClick={() => window.open(`/display/${event.id}`, '_blank')}
            >
              <Monitor className="w-5 h-5 mr-2" />
              開啟大螢幕
            </Button>
            
            <Button
              variant={event.is_active ? "outline" : "default"}
              size="lg"
              onClick={handleTogglePublic}
              disabled={isUpdating}
            >
              {isUpdating ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  處理中...
                </>
              ) : event.is_active ? (
                '🔒 關閉加入'
              ) : (
                '🔓 公開活動'
              )}
            </Button>

            {event.is_active && (
              <Button
                variant="gradient"
                size="lg"
                onClick={handleToggleMode}
                disabled={isUpdating}
              >
                {isUpdating ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    處理中...
                  </>
                ) : event.current_mode === 'lobby' ? (
                  '🚀 開始互動'
                ) : (
                  '⏸️ 返回等候室'
                )}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
